#define SECRET_OPTIONAL_PASS "idontknow"
#define SECRET_SSID "area51-r"
